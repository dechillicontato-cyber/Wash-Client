# Wash Client 1.0 — source starter

Open-source starter for a Minecraft Java Edition 1.8.9 Forge client-side mod.
Designed to be edited in Acode on Android and built in a cloud runner.

## Included
- Forge 1.8.9 mod entry point
- V keybind opens a settings screen
- Settings screen for CPS target range (12–18) and reference distance (3.5 blocks)
- Simple HUD overlay
- Mush public API lookup helper for `/player/{name}` (asynchronous request)
- GitHub Actions workflow for a legacy Gradle 2.7 build

## Important limitations
- The CPS and distance values are configuration/UI scaffolding only. This starter does **not** automate combat clicks or automate block breaking.
- The Mush API response schema can change. The lookup helper displays the raw JSON summary and does not claim to calculate every BedWars stat.
- This is source code, not a prebuilt JAR. The cloud build must succeed before installing it.
- Use only on servers where the server rules explicitly permit your mods.

## Android workflow (no Termux)
1. Extract this ZIP into a folder accessible to Acode.
2. Create a GitHub repository in your browser and upload the files/folders from this ZIP. GitHub's web UI can upload files; for a project with many files, upload the extracted folder using GitHub's web upload flow or a Git client app.
3. The included workflow runs on GitHub Actions. Open the repository's **Actions** tab and inspect the build.
4. On a successful run, download the artifact named `wash-client-jar` and extract the `.jar`.
5. Put the JAR into the `mods` folder of a Minecraft Java 1.8.9 + Forge installation on a supported desktop launcher. Acode/Android itself is not a Minecraft Java launcher or Java compiler.
6. Test in a local world first. The mod is client-side and does not grant server permissions.

## Build locally (desktop)
Use Java 8 and Gradle 2.7 for this legacy ForgeGradle setup. Run `gradle build`. The output should be under `build/libs/`.

## Mush API
Public API documentation: https://forum.mush.com.br/topic/149525/documenta%C3%A7%C3%A3o-api-mush
Profile endpoint pattern: `https://mush.com.br/api/player/{name}`
Use responsibly and avoid frequent requests.
