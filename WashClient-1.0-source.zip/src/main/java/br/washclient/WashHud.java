package br.washclient;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WashHud {
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Text event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;
        mc.fontRendererObj.drawStringWithShadow("Wash Client 1.0", 6, 6, 0xFF55FF);
        mc.fontRendererObj.drawStringWithShadow(
            "CPS config: " + WashClient.SETTINGS.minCps + "-" + WashClient.SETTINGS.maxCps +
            " | Ref: " + WashClient.SETTINGS.referenceDistance + "b",
            6, 17, 0xFFFFFF
        );
    }
}
