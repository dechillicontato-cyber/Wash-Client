package br.washclient;

public class Settings {
    public int minCps = 12;
    public int maxCps = 18;
    public float referenceDistance = 3.5F;

    public void normalize() {
        minCps = Math.max(1, Math.min(20, minCps));
        maxCps = Math.max(minCps, Math.min(25, maxCps));
        referenceDistance = Math.max(1.0F, Math.min(6.0F, referenceDistance));
    }
}
