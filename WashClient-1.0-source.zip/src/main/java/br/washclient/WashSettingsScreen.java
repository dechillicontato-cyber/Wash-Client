package br.washclient;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;

public class WashSettingsScreen extends GuiScreen {
    private GuiButton minCps;
    private GuiButton maxCps;
    private GuiButton distance;
    private GuiButton done;

    @Override
    public void initGui() {
        int x = this.width / 2 - 100;
        int y = this.height / 4;
        minCps = new GuiButton(1, x, y, 200, 20, "");
        maxCps = new GuiButton(2, x, y + 25, 200, 20, "");
        distance = new GuiButton(3, x, y + 50, 200, 20, "");
        done = new GuiButton(4, x, y + 85, 200, 20, "Fechar");
        buttonList.add(minCps);
        buttonList.add(maxCps);
        buttonList.add(distance);
        buttonList.add(done);
        refreshLabels();
    }

    private void refreshLabels() {
        WashClient.SETTINGS.normalize();
        minCps.displayString = "CPS minimo: " + WashClient.SETTINGS.minCps;
        maxCps.displayString = "CPS maximo: " + WashClient.SETTINGS.maxCps;
        distance.displayString = "Distancia ref.: " + WashClient.SETTINGS.referenceDistance + " blocos";
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            WashClient.SETTINGS.minCps++;
            if (WashClient.SETTINGS.minCps > 20) WashClient.SETTINGS.minCps = 1;
            if (WashClient.SETTINGS.minCps > WashClient.SETTINGS.maxCps)
                WashClient.SETTINGS.maxCps = WashClient.SETTINGS.minCps;
        } else if (button.id == 2) {
            WashClient.SETTINGS.maxCps++;
            if (WashClient.SETTINGS.maxCps > 25) WashClient.SETTINGS.maxCps = WashClient.SETTINGS.minCps;
        } else if (button.id == 3) {
            WashClient.SETTINGS.referenceDistance += 0.5F;
            if (WashClient.SETTINGS.referenceDistance > 6.0F) WashClient.SETTINGS.referenceDistance = 1.0F;
        } else if (button.id == 4) {
            mc.displayGuiScreen(null);
        }
        refreshLabels();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "WASH CLIENT 1.0", width / 2, height / 4 - 25, 0xFF55FF);
        drawCenteredString(fontRendererObj, "V abre este menu | BedWars / Mush Stats", width / 2, height / 4 - 12, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
        drawCenteredString(fontRendererObj, "CPS/distancia sao configuracoes de referencia; sem auto-combate.", width / 2, height - 18, 0xAAAAAA);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
