package br.washclient;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public final class MinecraftCheck {
    private MinecraftCheck() {}
    public static boolean playerPresent() {
        return Minecraft.getMinecraft().thePlayer != null;
    }
    public static void message(String text) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) mc.thePlayer.addChatMessage(new ChatComponentText(text));
    }
}
