package br.washclient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MushApi {
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private MushApi() {}

    public interface Callback {
        void done(String result, String error);
    }

    public static void fetchProfile(final String nick, final Callback callback) {
        WORKER.submit(new Runnable() {
            @Override public void run() {
                HttpURLConnection connection = null;
                try {
                    String encoded = URLEncoder.encode(nick, "UTF-8");
                    URL url = new URL("https://mush.com.br/api/player/" + encoded);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setRequestProperty("User-Agent", "WashClient/1.0 (public API client)");
                    int status = connection.getResponseCode();
                    if (status < 200 || status >= 300) {
                        callback.done(null, "HTTP " + status);
                        return;
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                        connection.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                    reader.close();
                    String json = body.toString();
                    // Keep chat output short; raw response schema may evolve.
                    String summary = json.length() > 220 ? json.substring(0, 220) + "..." : json;
                    callback.done(summary, null);
                } catch (Exception e) {
                    callback.done(null, e.getClass().getSimpleName() + ": " + e.getMessage());
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        });
    }
}
