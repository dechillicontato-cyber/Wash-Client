package br.washclient;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

public class MushCommand extends CommandBase {
    @Override public String getCommandName() { return "mushstats"; }
    @Override public String getCommandUsage(ICommandSender sender) { return "/mushstats <nick>"; }
    @Override public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 1 || !args[0].matches("[A-Za-z0-9_]{1,16}")) {
            sender.addChatMessage(new ChatComponentText("§cUse: /mushstats <nick>"));
            return;
        }
        final String nick = args[0];
        sender.addChatMessage(new ChatComponentText("§dWash Stats: §7consultando perfil de " + nick + "..."));
        MushApi.fetchProfile(nick, new MushApi.Callback() {
            @Override public void done(final String result, final String error) {
                net.minecraft.client.Minecraft.getMinecraft().addScheduledTask(new Runnable() {
                    @Override public void run() {
                        if (MinecraftCheck.playerPresent()) {
                            if (error != null) MinecraftCheck.message("§cMush API: " + error);
                            else MinecraftCheck.message("§dMush API §7(" + nick + "): §f" + result);
                        }
                    }
                });
            }
        });
    }
}
