package br.washclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = WashClient.MODID, name = "Wash Client", version = "1.0.0", acceptedMinecraftVersions = "[1.8.9]")
public class WashClient {
    public static final String MODID = "washclient";
    public static final Settings SETTINGS = new Settings();
    private KeyBinding openMenu;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        openMenu = new KeyBinding("Wash Client: Open settings", Keyboard.KEY_V, "Wash Client");
        net.minecraftforge.fml.client.registry.ClientRegistry.registerKeyBinding(openMenu);
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new WashHud());
        ClientCommandHandler.instance.registerCommand(new MushCommand());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (openMenu.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new WashSettingsScreen());
        }
    }
}
